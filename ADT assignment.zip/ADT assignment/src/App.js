import Home from './component/home'
import Form from './component/form'
import Employe from './component/employe'
import Empinfo from './component/empinfo'

import React from 'react'
import {
  Switch,
  Route,
} from "react-router-dom";

export default function App() {
  return (
    <div>
      <Switch>
          <Route exact path="/">
            <Home />
          </Route>
          <Route exact path="/form">
            <Form />
          </Route>
          <Route exact path="/employe">
            <Employe />
          </Route>
          <Route exact path="/empinfo">
            <Empinfo />
          </Route>
        </Switch>
    </div>
  )
}

