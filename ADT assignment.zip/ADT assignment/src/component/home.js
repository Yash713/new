import React from 'react'
import {Card,Button} from '@material-ui/core';
import { useHistory } from "react-router-dom";

export default function Home() {
   
    let history = useHistory();

    return (
        <div>
            <div style={{textAlign:"center",marginTop:"3%"}}>
            <h1 >Welcome</h1>
            
            </div>  
            <Card style={{maxWidth:"30%",minHeight:"100px",margin:"auto",marginTop:"7%",textAlign: "center"}}>
                <Button variant="contained" color="primary" onClick={()=>history.push("/form")
                    } style={{marginTop:"7%"}}>Add New Employee</Button>
            </Card>
            <Card style={{maxWidth:"30%",minHeight:"100px",margin:"auto",marginTop:"7%",textAlign: "center"}}>
                <Button variant="contained" color="primary" onClick={()=>history.push("/employe")} style={{marginTop:"7%"}}>Employee</Button>
            </Card>
        </div>
    )
}
