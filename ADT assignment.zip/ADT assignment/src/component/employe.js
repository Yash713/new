import React, { useEffect, useState } from 'react'
import { Card, Button, TablePagination, Table, TableBody, TableCell, TableHead, TableRow } from '@material-ui/core';
import { useHistory } from "react-router-dom";

export default function Employe() {
  let history = useHistory();
  const [list, setList] = useState([])
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);

  useEffect(() => {
    let list = window.localStorage.getItem('data')
    list = JSON.parse(list)
    setList(list)
  }, [])

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };
  return (
    <div>
      <Card style={{ margin: "auto", maxWidth: "70%", marginTop: "100px", padding: "2%", overflowX: 'auto' }}>
        <Table aria-label="simple table" style={{ minWidth: "50%" }}>
          <TableHead>
            <TableRow>
              <TableCell>Name</TableCell>
              <TableCell >Age</TableCell>
              <TableCell >Role</TableCell>
              <TableCell >Gender</TableCell>
              <TableCell >Email</TableCell>
              <TableCell>Phone</TableCell>
              <TableCell>Action</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {list.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row, i) => (
              <TableRow key={i}>
                <TableCell component="th" scope="row">
                  {row.name}
                </TableCell>
                <TableCell component="th" scope="row">
                  {row.age}
                </TableCell>
                <TableCell >{row.role}</TableCell>
                <TableCell>{row.gender}</TableCell>
                <TableCell >{row.email}</TableCell>
                <TableCell>{row.phone}</TableCell>
                <TableCell>
                  <Button variant="contained" size="small" onClick={() => {
                    history.push({
                      pathname: '/empinfo',
                      state: {
                        name: row.name,
                        age: row.age,
                        role: row.role,
                        gender: row.gender,
                        email: row.email,
                        phone: row.phone
                      }
                    })
                  }} color="secondary">View</Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        <TablePagination
          rowsPerPageOptions={[5, 10, 25]}
          component="div"
          count={list.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onChangePage={handleChangePage}
          onChangeRowsPerPage={handleChangeRowsPerPage}
        />
      </Card>
    </div>
  )
}
