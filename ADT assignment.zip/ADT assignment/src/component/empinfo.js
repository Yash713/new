import React, { useEffect, useState } from 'react'
import {Card} from '@material-ui/core';
import { useLocation } from "react-router-dom";

export default function Empinfo(props) {
    const location = useLocation();
    const [state,setState]=useState({
        name: '',
        age: "",
        role: "",
        gender: "",
        email: "",
        phone: ""
    })
    useEffect(() => {
        setState({
            name:location.state.name,
            age: location.state.age,
            role: location.state.role,
            gender: location.state.gender,
            email: location.state.email,
            phone: location.state.phone
        })
      }, [])
    return (

        <div>
            <Card style={{maxWidth:"50%",margin:"auto",marginTop:"1%",textAlign:"center"}}>
                 <h1>Hello {state.name} </h1>
                 <hr/>

                  <h3>Age:{state.age}</h3>
                  <h3>Role:{state.role}</h3>
                  <h3>Gender:{state.gender}</h3>
                  <h3>Email:{state.email}</h3>
                  <h3>Phone Number:{state.phone}</h3>
            </Card>
            
        </div>
    )
}
