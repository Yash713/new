
import React, { useState } from 'react'
import { Card, Select, FormControl, InputLabel, TextField, Button } from '@material-ui/core';
import { Row } from "reactstrap";
import Swal from 'sweetalert2'
import { useHistory } from "react-router-dom";

export default function Form() {
    let history = useHistory();

    const [state, setState] = useState({
        name: '',
        age: "",
        role: "",
        gender: "",
        email: "",
        phone: ""
    })
    const [errors, setErrors] = useState({})

    const handleChange = (e) => {
        setState((i) => ({
            ...i,
            [e.target.id]: e.target.value
        })
        )
    }

    const handleClick = () => {

        let d = window.localStorage.getItem('data')
        d = JSON.parse(d)        
        if (validate()) {
            let data =
            {
                name: state.name,
                age: state.age,
                role: state.role,
                gender: state.gender,
                email: state.email,
                phone: state.phone
            }
            d.push(data)
            window.localStorage.setItem("data", JSON.stringify(d))
            history.push("/employe")
            Swal.fire({
                icon: 'success',
                title: 'User Added Successfully',
            })

        }
    }

    const validate = () => {
        const { name, age, role, gender, email, phone } = state
        let formIsValid = true;
        if (name.trim() === '') {
            formIsValid = false
            setErrors((i) => ({
                ...i,
                name: 'Name is required'
            }))
        } else {
            setErrors((i) => ({
                ...i,
                name: ""
            }))
        }
        if (role.trim() === '') {
            formIsValid = false
            setErrors((i) => ({
                ...i,
                role: 'Role is required'
            }))
        }
        else {
            setErrors((i) => ({
                ...i,
                role: ""
            }))
        }
        if (age.trim() === '') {
            formIsValid = false
            setErrors((i) => ({
                ...i,
                age: 'Age is required'
            }))

        } else if (age < 18) {
            formIsValid = false
            setErrors((i) => ({
                ...i,
                age: 'Age must be greater than 18'
            }))
        }
        else {
            setErrors((i) => ({
                ...i,
                age: ""
            }))
        }

        if (gender.trim() === '') {
            formIsValid = false
            setErrors((i) => ({
                ...i,
                gender: 'Please select your Gender'
            }))
        } else {
            setErrors((i) => ({
                ...i,
                gender: ""
            }))
        }

        if (email.trim() === '') {
            formIsValid = false
            setErrors((i) => ({
                ...i,
                email: 'Email is required'
            }))
        }
        else if (!(/^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(email,))) {
            formIsValid = false
            setErrors((i) => ({
                ...i,
                email: 'Please enter a valid email'
            }))

        }
        else {
            setErrors((i) => ({
                ...i,
                email: ""
            }))
        }
        if (phone.trim() === '') {
            formIsValid = false
            setErrors((i) => ({
                ...i,
                phone: 'Phone number is required'
            }))
        } else if (phone.length !== 10) {
            formIsValid = false
            setErrors((i) => ({
                ...i,
                phone: 'Phone number must be of ten digit'
            }))
        }
        else {
            setErrors((i) => ({
                ...i,
                phone: ""
            }))
        }

        return formIsValid;

    };

    return (
        <div>

            <Card style={{
                maxWidth: "50%",
                margin: "auto",
                padding: "2%"
            }}>
                <Row style={{ "marginLeft": "10%", "marginRight": "10%" }}>
                    <TextField
                        required
                        id="name"
                        label="Your Name"
                        value={state.name}
                        type="text"
                        margin="normal"
                        fullWidth={true}
                        onChange={handleChange}
                    />
                    <p style={{ color: "red", fontSize: "14px" }}>{errors["name"]}</p>
                </Row>
                <Row style={{ "marginLeft": "10%", "marginRight": "10%" }}>
                    <TextField
                        required
                        id="age"
                        label="Age"
                        value={state.age}
                        type="number"
                        margin="normal"
                        fullWidth={true}
                        onChange={handleChange}
                    />
                    <p style={{ color: "red", fontSize: "14px" }}>{errors["age"]}</p>
                </Row>
                <Row style={{ "marginLeft": "10%", "marginRight": "10%" }}>
                    <TextField
                        required
                        id="role"
                        label="Role"
                        value={state.role}
                        type="text"
                        margin="normal"
                        fullWidth={true}
                        onChange={handleChange}
                    />
                    <p style={{ color: "red", fontSize: "14px" }}>{errors["role"]}</p>
                </Row>
                <br />
                <Row style={{ "marginLeft": "10%", "marginRight": "10%" }}>
                    <FormControl style={{ minWidth: " 100%" }}>
                        <InputLabel required htmlFor="gender">Gender</InputLabel>
                        <Select
                            native
                            value={state.gender}
                            onChange={handleChange}
                            inputProps={{
                                id: 'gender',
                            }}
                            style={{ "maxWidth": "70% !inportant" }}
                        >   <option value={" "}></option>
                            <option value={"male"}>Male</option>
                            <option value={"female"}>Female</option>
                        </Select>
                        <p style={{ color: "red", fontSize: "14px" }}>{errors["gender"]}</p>
                    </FormControl>
                </Row>
                <Row style={{ "marginLeft": "10%", "marginRight": "10%" }}>
                    <TextField
                        required
                        id="email"
                        label="Email"
                        value={state.email}
                        type="email"
                        margin="normal"
                        fullWidth={true}
                        onChange={handleChange}
                    />
                    <p style={{ color: "red", fontSize: "14px" }}>{errors["email"]}</p>
                </Row>
                <Row style={{ "marginLeft": "10%", "marginRight": "10%" }}>
                    <TextField
                        required
                        id="phone"
                        label="Number"
                        value={state.phone}
                        type="number"
                        margin="normal"
                        fullWidth={true}
                        onChange={handleChange}
                    />
                    <p style={{ color: "red", fontSize: "14px" }}>{errors["phone"]}</p>
                </Row>
                <br />
                <Row style={{ textAlign: "center" }}>
                    <Button variant="contained" onClick={handleClick} color="primary">Add</Button> {' '}
                    <Button variant="contained" color="gray" onClick={() => history.push("/")}>Cancel</Button>
                </Row>
            </Card>
        </div>
    )
}
